import os
import json
import requests
from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from dotenv import load_dotenv
from database import init_db, save_project, get_all_projects, get_project, delete_project

load_dotenv()

app = Flask(__name__)
CORS(app)

ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")
ANTHROPIC_URL = "https://api.anthropic.com/v1/messages"
CLAUDE_MODEL = "claude-sonnet-4-6"


# ── PAGES ──

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/project/<int:project_id>")
def project_page(project_id):
    return render_template("index.html")


# ── API: GENERATE ──

@app.route("/api/generate", methods=["POST"])
def generate():
    data = request.get_json()
    script = data.get("script", "").strip()
    genre  = data.get("genre", "sci-fi thriller")
    style  = data.get("style", "cinematic")
    count  = int(data.get("count", 5))

    if not script:
        return jsonify({"error": "Script is required."}), 400

    if not ANTHROPIC_API_KEY or ANTHROPIC_API_KEY == "your_api_key_here":
        return jsonify({"error": "ANTHROPIC_API_KEY not set in .env file."}), 500

    system_prompt = """You are a professional film script supervisor and AI cinematography director for a Generative OTT platform. Your job is to break a story into cinematic scenes and produce structured data for AI video generation.

Return ONLY valid JSON — no markdown, no backticks, no explanation. Use this exact format:
{
  "title": "Short film title (4-6 words)",
  "scenes": [
    {
      "title": "Scene title (5 words max)",
      "type": "Interior or Exterior",
      "setting": "Specific location description",
      "mood": "Single mood word",
      "characters": "Main characters present",
      "duration": "Estimated screen time e.g. 2 min",
      "description": "Vivid 2-3 sentence cinematic description of what happens and what the camera sees. Be specific about visuals — lighting, camera angles, action, expressions.",
      "video_prompt": "A detailed, ready-to-use AI video generation prompt for this scene. Include: the action, setting, lighting style, camera movement, visual aesthetic, mood, and technical specs (e.g. 4K, cinematic, film grain)."
    }
  ]
}"""

    user_prompt = f"""Break this story into exactly {count} cinematic scenes for a {genre} film with {style} visual style.

Story:
{script}

Return exactly {count} scenes. Make video_prompt very detailed and specific — it will be pasted directly into Veo 3.1, Runway, or LTX-Video."""

    try:
        response = requests.post(
            ANTHROPIC_URL,
            headers={
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": CLAUDE_MODEL,
                "max_tokens": 2000,
                "system": system_prompt,
                "messages": [{"role": "user", "content": user_prompt}],
            },
            timeout=60,
        )

        resp_data = response.json()

        if "error" in resp_data:
            return jsonify({"error": resp_data["error"]["message"]}), 500

        raw = resp_data["content"][0]["text"]
        clean = raw.replace("```json", "").replace("```", "").strip()
        parsed = json.loads(clean)

        return jsonify({
            "title": parsed.get("title", "Untitled Film"),
            "scenes": parsed.get("scenes", []),
        })

    except json.JSONDecodeError as e:
        return jsonify({"error": f"AI returned invalid JSON: {str(e)}"}), 500
    except requests.exceptions.Timeout:
        return jsonify({"error": "Request timed out. Try again."}), 504
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ── API: PROJECTS ──

@app.route("/api/projects", methods=["GET"])
def api_get_projects():
    return jsonify(get_all_projects())


@app.route("/api/projects", methods=["POST"])
def api_save_project():
    data = request.get_json()
    title  = data.get("title", "Untitled Film")
    script = data.get("script", "")
    genre  = data.get("genre", "")
    style  = data.get("style", "")
    scenes = data.get("scenes", [])

    if not script or not scenes:
        return jsonify({"error": "script and scenes are required."}), 400

    project_id = save_project(title, script, genre, style, scenes)
    return jsonify({"id": project_id, "message": "Project saved."}), 201


@app.route("/api/projects/<int:project_id>", methods=["GET"])
def api_get_project(project_id):
    project = get_project(project_id)
    if not project:
        return jsonify({"error": "Project not found."}), 404
    return jsonify(project)


@app.route("/api/projects/<int:project_id>", methods=["DELETE"])
def api_delete_project(project_id):
    delete_project(project_id)
    return jsonify({"message": "Deleted."})


# ── RUN ──

if __name__ == "__main__":
    init_db()
    print("\n[GenOTT] Running at http://localhost:5000\n")
    app.run(debug=True, port=5000)
